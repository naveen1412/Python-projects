#In Python, function is a group of related statements that perform a specific task.
#Function Declaration

def greet_me(name):
    print("Good Morning "+name)

def add_integers(a, b):
    return a+b

greet_me("Naveen ")
print(add_integers(2, 3))
