
values = [1, 2, "rahul", 4, 5,6,'asd',9,'true']
# List is data type that allows multiple values and can be different data types

print(values[0])  # 1

print(values[3])  # 4
print(values[-1])  #true
print(values[1:7])  # 2 rahul till asd
values.insert(3, "shetty")   #[1, 2, 'rahul', 'shetty', 4, 5]
print(values)
values.append("End")  #[1, 2, 'rahul', 'shetty', 4, 5, 'End']
print(values)

#values[2] = "NAVEEN" #Updating
print("----------------------------------")
del values[3]
print(values)
print("----------------------------------")
values.remove('asd')
print(values)
print("----------------------------------")

# Tuple - Same as LIST Data type but immutable
val = (1, 2, "rahul", 4.5)

print(val[1])

#val[2] = "RAHUL" - cannot update
# val.insert(3,'s')  -error
# val.append("end")  -error
# del val[3]         -error
print(val)

# Dictionary unordered key value pairs - mutable
dic = {"a": 2, 4:"bcd", "c": "Hello world","z":16}

print(dic[4])
print(dic["a"])
dic[4]= "appended"
del dic["c"]
print(dic)

#
dict1 = {}

dict1["firstname"] = "NAVEEN"

dict1["lastname"] = "D"

dict1["gender"] = "Male"

print(dict1)
print(dict1["lastname"])
print(dict1["gender"])

#SET - Unordered collection, mutable, non-repetitive
s1 = set("google")
print(s1)
s2 = set(["26", 3 , "gone", "done", "26", 3])
print(s2)
set.add(s2,'ha')
print(s2)
set.pop(s2)
print(s2)
s2.add(55)
print(s2)
print(s2.pop())