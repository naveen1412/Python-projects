print("hello")
# Single line comments
'''Multi 
line 
comments 
'''
a = 3
print(a)

Str = "Hello World"
print(Str)

b, c, d = 5, 6.4, "Great"

print("Value is "+str(b)+" fdfd")

print("{} {}".format("Value is", b))
print(c)
print(d)
print(type(b))

print(type(c))
print(type(d))







