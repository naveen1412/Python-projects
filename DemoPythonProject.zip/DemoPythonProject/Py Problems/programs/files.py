#files
"""
with open('test.txt') as reader:
OR
with open('test.txt','r') as reader:
OR
file = open('test.txt')
print(file.read()) read all the content in file
print(file.readline())   read one single line at a time till /n
print(file.readline(3))  read from current position to next 3 characters
for i in range(1, 5):
   print(file.readline())  - read 5 lines because of loop """

#print line by line using readline()
file = open('test.txt')
line = file.readline()
while line!= '':
    print(line)
   # line = file.readline()
file.close()


'''with open('test1.txt') as filea:
    for line in filea:
        print(line)
'''

#USING readlines()
'''with open('test1.txt') as reader:
    for line in reader.readlines():
        print(line)
'''
#reverse
'''with open('test.txt', 'r') as reader:
    content = reader.readlines()
    with open('test1.txt', 'w') as writer:
        for line in reversed(content):
            writer.write(line)
'''

