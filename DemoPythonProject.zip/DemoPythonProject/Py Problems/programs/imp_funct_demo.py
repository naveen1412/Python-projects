#import FunctionsDemo as f1
from FunctionsDemo import *
#will first execute statements - outside of classes and functions in FunctionsDemo module
print(add_integers(3,3))

greet_me("hello")

#print(a)