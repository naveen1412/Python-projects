str = "RahulShettyAcademy.com"
str1 = "Consulting firm"
str3 = "RahulShetty"

print(str[1])   #a

print(str[0:5])  # Slicing - if you want substring in python

print(str+str1)   # concatenation

print(str3 in str)  # substring check
#str5 = str.join(str3)   #Use is iterable
#print(str5)
print(str)
var = str.split(".") # splits and returns list
print(var)
print(var[0])
str4 = " great "
print(str4.strip('t'))
print(str4.lstrip())

print(str4.rstrip())









