from OopsDemo import Calculator


class ChildImpl(Calculator):
    num2 = 200

    def __init__(self, a, b):
        Calculator.__init__(self, a, b)

    def get_complete_data(self):
        return self.num2 + self.num + self.summation()


obj = ChildImpl(2,10)
print(obj.get_complete_data())
obj.get_data()