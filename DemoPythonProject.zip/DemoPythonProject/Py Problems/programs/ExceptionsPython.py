
#try , catch

try:
    with open('test.txt', 'r') as reader:
        reader.read()

except:
    print("SOme how i reached this block because there is failure in try block")


try:
    with open('tesst.txt', 'r') as reader:
        reader.read()

except Exception as e:
    print(e)

finally:
    print("cleaning up records")









