import random

print('Hi, What is your name?')
userName = input()
flag = False
number = random.randint(1,20)
print('Hi '+userName+' I was thinking a number between 1 and 20, could you take a guess')
for i in range(1,6):
    userNumber = int(input())
    if userNumber < number:
        print('guess a little high')
        continue
    elif userNumber > number:
        print('guess a little low')
        continue
    else:
        print('Correct guess')
        flag = True
        break
if flag:
    print('yes the number is '+str(number))
else:
    print('No the number i was thinking is '+str(number))
