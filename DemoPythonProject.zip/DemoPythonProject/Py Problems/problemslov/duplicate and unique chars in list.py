list = ['India','is','my','county']
s = ''.join(list)
str = s.lower()
print(str)
duplicatesChars = []
for char in str:
    if str.count(char)>1 and char not in duplicatesChars:
        duplicatesChars.append(char)
print('Duplicate chars are ')
print(duplicatesChars)
print(*duplicatesChars)
uniqueChars = []
for char in str:
    if str.count(char)==1 and char not in uniqueChars:
        uniqueChars.append(char)

print('Unique chars are ')
print(uniqueChars)
print(*uniqueChars)