'''
list1 = ['my','name']
list2 = ['is','Naveen']
output: My name is Naveen
'''
list1 = ['my','name']
list2 = ['is','Naveen']
list3 = list1+list2
print(list3)
#OR
list1.extend(list2)
print(list1)
print(' '.join(list1))