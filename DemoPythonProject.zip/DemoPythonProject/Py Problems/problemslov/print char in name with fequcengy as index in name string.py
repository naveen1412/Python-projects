name= "Naveen"
for i, char in enumerate(name, start=1):
        print(char * i,end= "")
print()
#OR
position = 1
for char in name:
    print(char * position,end= "")
    position += 1