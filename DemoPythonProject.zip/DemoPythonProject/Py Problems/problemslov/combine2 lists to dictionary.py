list1 = ['a','b','c']
list2 = [1,2,3,]
dic = dict(zip(list1,list2))
print(dic)

#OR

dict1 = {list1[i] : list2[i] for i in range(len(list1))}
print(dict1)

#OR

dict2 = {}
for key in list1:
    for value in list2:
        dict2[key] = value
        list2.remove(value)
        break
print(dict2)