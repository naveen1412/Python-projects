list = ['India','is','my','county']
str = ''.join(list)
str1=str.lower()
print(str1)

vowels = ['a','e','i','o','u']

str2= [char for char in str1 if char not in vowels]
print(str2)
print(''.join(str2))

#OR
list1 = []
for char in str1:
    if char not in vowels:
        list1.append(char)
print(list1)

