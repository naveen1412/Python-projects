str = 'India blr'
print(str[-1])  #r
print(str[:-1])  # India bl
print(str[::-1])  # rlb aidnI
print(str[:2])   # In
print(str[::2])   # Idabr