list = ['India','is','my','county',]
list1 =[word for word in list if word.startswith('i') or word.startswith('I')]
print(list1)

#OR

list2 = []
for i in list:
    if i.startswith('i') or i.startswith('I'):
        list2.append(i)
print(list2)