class A:
    count = 0
    def __init__(self):
        A.count += 1
        #print('class is called')

a1 = A()
a2 = A()
for i in range(0,10):
    a3 = A()
    #print(i)

print(A.count)

# mtd 2
c = 0
class B:
    def __init__(self):
        global c
        c += 1
        #print('class is called')
b1 = B()
b2 = B()
for j in range(0, 20):
    b3 =B()
    #print(j)
a4 = A()
print(c)
print(A.count)