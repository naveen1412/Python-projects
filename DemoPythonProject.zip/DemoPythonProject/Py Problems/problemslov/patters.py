""" Write logic for this pattern
1
2 2
3 3 3
4 4 4 4
5 5 5 5 5
4 4 4 4
3 3 3
2 2
1"""
print("1to5 and 5to1")
for i in range(1,6):
    for j in range(i):
        print(i,end = " ")
    print()

for i in range(4,0,-1):
    for j in range(i):
        print(i,end = " ")
    print()
print("--------------------------------------------------------------------")
""" Write logic for this pattern
   1   
  2 2  
 3 3 3 
4 4 4 4
"""
print("1to4 in pyramid ")
# Number of rows
n = 4

# Loop through each row
for i in range(1, n+1):
    # Print leading spaces to align the numbers to the right
    for j in range(n - i):
        print(" ", end="")

    # Print the number repeated i times
    for j in range(i):
        print(i, end=" ")

    # Move to the next line after each row
    print()

print("--------------------------------------------------------------------")
""" Write logic for this pattern
4 4 4 4 
 3 3 3 
  2 2 
   1 
"""
print("4to1 in reversed pyramid ")
n = 4

# Loop through each row
for i in range(n, 0,-1):
    # Print leading spaces to align the numbers to the right
    for j in range(n - i):
        print(" ", end="")

    # Print the number repeated i times
    for j in range(i):
        print(i, end=" ")

    # Move to the next line after each row
    print()
