from time import sleep

from selenium import webdriver

#chrome driver
from selenium.webdriver import ActionChains
#from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By

#service_obj = Service("/Users/rahulshetty/documents/chromedriver")
driver = webdriver.Chrome()
driver.implicitly_wait(5)
driver.maximize_window()
driver.get("https://rahulshettyacademy.com/AutomationPractice/")
action = ActionChains(driver)
action.double_click(driver.find_element(By.ID,"autocomplete")).perform()
action.context_click(driver.find_element(By.ID,"opentab")).perform()
#action.drag_and_drop(((driver.find_element(By.CLASS_NAME,"btn-style class1")),(driver.find_element(By.CLASS_NAME,"inputs")))).perform()
action.move_to_element(driver.find_element(By.ID,"mousehover")).perform()
driver.implicitly_wait(5)
action.move_to_element(driver.find_element(By.XPATH,"//input[@id='alertbtn']")).perform()
action.move_to_element(driver.find_element(By.LINK_TEXT,"Home")).perform()
sleep(5)
action.move_to_element(driver.find_element(By.ID,"mousehover")).perform()

action.move_to_element(driver.find_element(By.LINK_TEXT,"Reload")).click().perform()
driver.implicitly_wait(5)
