print('range')
for i in range(1,20,2):
    print(i)
print('reverse range')
for i in range(20,0,-2):
    print(i)
