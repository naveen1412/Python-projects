#parameterisation same test for multiple agrs
import pytest


class Testp:
    @pytest.mark.parametrize("numbers",['1','2','3'])
    def test_b(self, numbers):
        print("numbers {}".format(numbers))