#test_pytest_mtd to run fixture in another fixture
import pytest

class Testo:
    @pytest.fixture()
    def mymtd(self):
        print("fixture 1 mtd")
        return "hello"

    @pytest.fixture()
    def mymtd1(self, mymtd):
        print("fixture 2 mtd")
        return mymtd + "world"

    def test_mtd(self, mymtd1):
        print("1")
        print(mymtd1)

    def test_mtd2(self):
        print("2")

    def test_mtd3(self, mymtd):
        print("3")
        print(mymtd)