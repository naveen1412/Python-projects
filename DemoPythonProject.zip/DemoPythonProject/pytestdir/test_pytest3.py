#test_pytest_mtd to run mtd before particular mtd using fixture
import pytest

class Testo:
    @pytest.fixture()
    def mymtd(self, request):
        print("fixture mtd")
        return "hello"
    def test_mtd(self, mymtd):
        print("1")

    def test_mtd2(self):
        print("2")

    def test_mtd3(self, mymtd):
        print("3")
        print(mymtd)