#test_pytest_mtd to run mtd before all Class using fixture
#name this file as conftest.py
import pytest

@pytest.fixture(scope='session', autouse=True)
def myfixture():
    print("all Class fixture mtd")
