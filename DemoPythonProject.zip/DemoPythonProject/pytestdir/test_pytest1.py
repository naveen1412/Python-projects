#test_pytest_mtd to run mtd before each mtd using fixture
#teardown for after each mtd
import pytest

class Testm:
    @pytest.fixture(scope='function', autouse=True)
    def mymtd(self, request):
        print("fixture mtd")
        def teardown():
            print("teardown mtd")
        request.addfinalizer(teardown)
    def test_mtd(self):
        print("1")

    def test_mtd2(self):
        print("2")

    def test_mtd3(self):
        print("3")