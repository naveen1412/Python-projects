#test_pytest_mtd to run mtd before all mtd using fixture
import pytest

class Testn:
    @pytest.fixture(scope='class', autouse=True)
    def mymtd(self):
        print("1 Class fixture mtd")

    def test_mtd(self):
        print("a")

    def test_mtd2(self):
        print("b")

    def test_mtd3(self):
        print("c")